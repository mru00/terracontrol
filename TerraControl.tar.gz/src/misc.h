#ifndef _MISC_H_
#define _MISC_H_

#include <avr/io.h>
#include <stdint.h>

#define _out_
#define _in_
#define _in_out_


#define TRUE 1
#define FALSE 0


void sleep(uint16_t time);

#endif
