/* 
 * terrarium control
 * mru, november 2009
 *
 * serial command line interface
 *
 */


//#define COMMANDLINE_DEBUG

extern void commandline_init(void);
extern void commandline_addchar(char c);

