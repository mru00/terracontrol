/* 
 * terrarium control
 * mru, november 2009
 *
 */




extern void selftest_perform(void);
