#include "misc.h"


void sleep(uint16_t time) {

  while (time) time --;

}
