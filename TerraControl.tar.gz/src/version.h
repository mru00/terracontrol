/* 
 * terrarium control
 * mru, november 2009
 *
 * serial commandline interface
 */



#define VERSION "0.1"
